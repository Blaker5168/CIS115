﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DailyTemp
{
    public partial class Form1 : Form
    {
        
        private int totalTemperature = 0;
        private int validTemperaturesCount = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            int temp;
            if (int.TryParse(txtTemperature.Text, out temp) && temp >= -20 && temp <= 130)
            {
                
                totalTemperature += temp;
                validTemperaturesCount++;
                lstTemperatures.Items.Add(temp.ToString());
                lblMessage.Text = "";

                if (validTemperaturesCount == 7)
                {
                    btnEnter.Enabled = false;
                    double averageTemp = (double)totalTemperature / validTemperaturesCount;
                    lblMessage.Text = $"Average Temperature: {averageTemp:F2}";
                }
            }
            else
            {
                
                lblMessage.Text = "Invalid temperature. Enter a value between -20 and 130.";
            }
            txtTemperature.Clear();
            txtTemperature.Focus();
        }
    }
}
