﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NEWModule3Movers
{
    public partial class Fourm1 : Form
    {
        public Fourm1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            
            const decimal baseRate = 200m;
            const decimal hourlyRate = 150m;
            const decimal perMileRate = 2m;

            
            bool hoursParsed = decimal.TryParse(txtHours.Text, out decimal hours);
            bool milesParsed = decimal.TryParse(txtMiles.Text, out decimal miles);

            
            if (!hoursParsed || !milesParsed || hours < 0 || miles < 0)
            {
                MessageBox.Show("Please enter valid positive numbers for hours and miles.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; 
            }

            
            decimal totalCost = baseRate + (hours * hourlyRate) + (miles * perMileRate);

            
            lblResult.Text = $"For a move taking {hours} hours and going {miles} miles the estimate is {totalCost:C2}.";
        }
    }
}
