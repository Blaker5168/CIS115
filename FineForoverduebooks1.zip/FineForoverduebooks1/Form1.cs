﻿using System;
using System.Windows.Forms;

namespace FineForOverdueBooks1
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            this.InitializeFormComponents(); 
        }

        
        private void InitializeFormComponents()
        {
            
            Button btnCalculate = new Button
            {
                Text = "Calculate Fine",
                Location = new System.Drawing.Point(100, 100), 
                Size = new System.Drawing.Size(100, 50) 
            };
            btnCalculate.Click += btnCalculate_Click; 
            this.Controls.Add(btnCalculate); 

            
        }

        
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                int numberOfBooks = int.Parse(txtBooks.Text); 
                int daysOverdue = int.Parse(txtDaysOverdue.Text); 
                decimal fine = CalculateFine(numberOfBooks, daysOverdue);
                lblResult.Text = $"Total Fine: ${fine:F2}"; 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        
        private decimal CalculateFine(int books, int days)
        {
            decimal fine = 0m;
            if (days <= 7)
            {
                fine = days * books * 0.10m;
            }
            else
            {
                fine = 7 * books * 0.10m + (days - 7) * books * 0.20m;
            }
            return fine;
        }
    }
}
