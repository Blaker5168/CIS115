﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PigLatin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            
            string originalWord = textBox1.Text.Trim().ToLower();
            if (!string.IsNullOrEmpty(originalWord))
            {
                
                string pigLatinWord = originalWord.Substring(1) + originalWord[0] + "ay";
                
                label1.Text = pigLatinWord;
            }
            else
            {
                
                label1.Text = "Please enter a word.";
            }
        }
    }
}
